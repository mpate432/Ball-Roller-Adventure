using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacles : MonoBehaviour
{    
    public float travelDistanceX;
    public float travelDistanceZ;
    public float speed = 2f; 
    // Update is called once per frame
    void Update() {
        if(travelDistanceX == 0){
            transform.position = new Vector3(transform.position.x, transform.position.y, Mathf.PingPong(Time.time * speed,travelDistanceZ));
        }
        else if(travelDistanceZ == 0){
            transform.position = new Vector3(Mathf.PingPong(Time.time * speed,travelDistanceX), transform.position.y, transform.position.z);
        }
        else{
            transform.position = new Vector3(Mathf.PingPong(Time.time * speed,travelDistanceX), transform.position.y, Mathf.PingPong(Time.time * speed,travelDistanceZ));
        }
    }
}
