using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{   
    public float speed; // speed magnitude multiplier
    private Rigidbody rb;
    private int score = 0;
    public Text value;
    private int coinCount;
    private int gemCount;
    
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        
    }

    // Update is called once per frame
    void Update()
    {
     float xDirection = Input.GetAxis("Horizontal"); //ball movement along axis in WASD
     float zDirection = Input.GetAxis("Vertical");

     Vector3 movement = new Vector3(xDirection, 0.0f, zDirection);
     rb.AddForce(movement * speed);//Applying force to the rigidbody on the ball

     if(coinCount == 4 && gemCount == 4){
         Invoke("ResetScene",2f);
     }
    }

    private void OnTriggerEnter(Collider collision) {
        if(collision.CompareTag("Collectable")){
            Destroy(collision.gameObject); //when the object collides it will disappear
            collision.gameObject.SetActive(false); //false deactivates the object
            score = score + 1; 
            value.text = "Score: " + score.ToString();
            coinCount++;
        }
        else if(collision.CompareTag("CollectableGems")){
            
            Destroy(collision.gameObject);
            collision.gameObject.SetActive(false);
            score = score + 3; 
            value.text = "Score: " + score.ToString();
            gemCount++;
        }
        else if(collision.CompareTag("Avoid")){
            Invoke("ResetScene",0.1f);      
        }
        else if(collision.CompareTag("ScoreMultiplier")){
            Destroy(collision.gameObject);
            collision.gameObject.SetActive(false);
            score = score * 2; 
            value.text = "Score: " + score.ToString();
        }        
    }

    public void ResetScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}

