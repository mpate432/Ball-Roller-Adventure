using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotator : MonoBehaviour
{   
    public float rotationSpeed = 50f;
    public bool spinX;
    public bool spinY;
    public bool spinZ;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {   
        if(spinX){
            this.transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);
        }
        else if(spinY){
        
            this.transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime);
        }
        else if(spinZ){
            this.transform.Rotate(Vector3.right * rotationSpeed * Time.deltaTime);
        }
        
    }
}
