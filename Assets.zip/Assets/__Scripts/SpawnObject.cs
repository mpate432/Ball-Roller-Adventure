using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnObject : MonoBehaviour
{   
    public GameObject objectToSpawn;
    public float setTime;
    // Start is called before the first frame update
    void Start()
    {
        Spawn();
    }

    // Update is called once per frame
    void Update()
    {
    
    }

    void Spawn(){
        Instantiate(objectToSpawn, this.transform.position, objectToSpawn.transform.rotation);
    }
}
